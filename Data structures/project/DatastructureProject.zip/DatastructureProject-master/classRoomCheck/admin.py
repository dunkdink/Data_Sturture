from django.contrib import admin
from .models import AllClassRooM
# Register your models here.

admin.site.register(AllClassRooM)