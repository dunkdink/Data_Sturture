from django.apps import AppConfig


class ClassroomcheckConfig(AppConfig):
    name = 'classRoomCheck'
